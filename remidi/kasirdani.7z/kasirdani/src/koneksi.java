import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author rpl a
 */
public class koneksi {
 Connection connect=null;
    public static Connection koneksi(){
    try {
    String url="jdbc:mysql://localhost/kasir";
    String user="root";
    String pass="";
    Class.forName("com.mysql.jdbc.Driver");
    Connection koneksi=DriverManager.getConnection(url,user,pass);
    return koneksi;
    }
    catch (Exception e){
    JOptionPane.showMessageDialog(null, e);
    return null;
    }
    }
    }
